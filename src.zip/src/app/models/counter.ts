export class Counter {
    value: number;
}

import { Product } from './product';
export class Item {
    id?: string;
    quantity?: number;
    product: Product;
}

import { Item } from './item';
export class ShoppingCart {
    items: Item[];
    itemsCount: { value: number };
}

import { Product } from './product';
import { Item } from './item';
export class ShoppingCart {
    items: Item[];
    itemsCount: { value: number };
    constructor() {}
}

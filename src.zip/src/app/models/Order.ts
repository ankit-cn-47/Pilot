import { ShoppingCart } from './shopping-carts';

export class Order {

    datePlaced: number;
    shippingAddress;
    items: any[];
    orderId: string;

    constructor(public userId: string, public address: any, cart: ShoppingCart) {
        this.datePlaced = Date.now();
        this.shippingAddress = address;
        this.items = cart.items;
    }
}

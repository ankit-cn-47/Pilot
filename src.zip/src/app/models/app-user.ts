export interface AppUser {
    name: string;
    email: string;
    admin: {isAdmin: boolean};
    userId: string;
}

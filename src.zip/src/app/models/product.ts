export interface Product {
    title: string;
    price: number;
    image: string;
    id?: string;
    category: string;
}

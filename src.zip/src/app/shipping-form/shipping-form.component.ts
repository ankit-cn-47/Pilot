import { Router } from '@angular/router';
import { AuthService } from './../services/auth.service';
import { OrderService } from './../services/order.service';
import { Subscription } from 'rxjs';
import { ShoppingCart } from './../models/shopping-carts';
import { Order } from './../models/Order';
import { ShoppingCartService } from './../services/shopping-cart.service';
import { Component, OnInit, OnDestroy } from '@angular/core';

@Component({
  selector: 'app-shipping-form',
  templateUrl: './shipping-form.component.html',
  styleUrls: ['./shipping-form.component.css']
})
export class ShippingFormComponent implements OnInit, OnDestroy {

  constructor(private cartService: ShoppingCartService,
    private orderService: OrderService,
    private authService: AuthService,
    private router: Router) {}

  shipping = {};
  cart: ShoppingCart;
  cartSubscription: Subscription;
  userId: string;
  userSubscription: Subscription;

  async ngOnInit() {
    const cartAFO = await this.cartService.getCart();
    this.cartSubscription = cartAFO.valueChanges().subscribe (cart => this.cart = cart);
    this.userSubscription = this.authService.user$.subscribe(user => this.userId = user.uid);
  }

  async placeOrder() {
    const order = new Order(this.userId, this.shipping, this.cart);
    const orderId = await this.orderService.placeOrder(order);
    this.router.navigate(['order-success', orderId]);
  }

  ngOnDestroy() {
    this.cartSubscription.unsubscribe();
    this.userSubscription.unsubscribe();
  }
}

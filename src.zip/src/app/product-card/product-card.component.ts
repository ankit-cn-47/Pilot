import { Component, OnInit, Input } from '@angular/core';
import { Product } from '../models/product';
import { ShoppingCartService } from '../services/shopping-cart.service';

@Component({
  // tslint:disable-next-line:component-selector
  selector: 'product-card',
  templateUrl: './product-card.component.html',
  styleUrls: ['./product-card.component.css']
})
export class ProductCardComponent implements OnInit {

  @Input() product;
  @Input() showActions = true;
  @Input() shoppingCart;

  constructor(private cartService: ShoppingCartService) { }

  ngOnInit() {
  }

  addToCart() {
    this.cartService.addToCart(this.product);
  }

  getQuantity() {
    if (!(this.shoppingCart.items) || !(this.shoppingCart.items[this.product.id])) {return 0;
    } else {
    const item = this.shoppingCart.items[this.product.id];
    return item.quantity ;
    }
  }

  removeFromCart() {
    this.cartService.removeFromCart(this.product);
  }

}

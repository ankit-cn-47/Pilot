import { OrderService } from './../services/order.service';
import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-user-order-list',
  templateUrl: './user-order-list.component.html',
  styleUrls: ['./user-order-list.component.css']
})
export class UserOrderListComponent implements OnInit {

  @Input() orderId;
  items$;

  constructor(orderService: OrderService) {
    this.items$ = orderService.getOrderedItems(this.orderId).valueChanges();
  }

  ngOnInit() {
  }

}

import { Product } from './../models/product';
import { Item } from './../models/item';
import { ShoppingCart } from './../models/shopping-carts';
import { Subscription, Observable } from 'rxjs';

import { ShoppingCartService } from './../services/shopping-cart.service';
import { Component, OnInit, OnDestroy } from '@angular/core';

@Component({
  selector: 'app-shopping-cart',
  templateUrl: './shopping-cart.component.html',
  styleUrls: ['./shopping-cart.component.css']
})
export class ShoppingCartComponent implements OnInit, OnDestroy {

  itemsCount: number;
  total: number;
  items$: Observable<Item[]>;
  subscription: Subscription;
  subscription2: Subscription;
  cart$: Observable<ShoppingCart>;

  constructor(private cartService: ShoppingCartService) {
  }

  async ngOnInit() {
    const cart = await this.cartService.getCart();
    this.cart$ = cart.valueChanges();
    this.subscription = this.cart$.subscribe(cartIn => {
      this.itemsCount = cartIn.itemsCount.value;
    });

    const itemsAFL = await this.cartService.getItems();
    this.items$ = itemsAFL.valueChanges();
    this.subscription2 = this.items$.subscribe(x => {
      this.total = 0;
      for (const i of x) {
        this.total = this.total + ((i.product.price) * (i.quantity));
      }
    });
  }
  add(product: Product) {
    this.cartService.addToCart(product);
  }
  remove(product: Product) {
    this.cartService.removeFromCart(product);
  }

  ngOnDestroy() {
    this.subscription.unsubscribe();
    this.subscription2.unsubscribe();
  }
}

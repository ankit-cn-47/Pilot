import { Counter } from './../models/counter';
import { ShoppingCart } from './../models/shopping-carts';
import { AngularFireDatabase, AngularFireObject, AngularFireList } from 'angularfire2/database';
import { Injectable } from '@angular/core';
import { Product } from '../models/product';
import { Item } from '../models/item';
import { take } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class ShoppingCartService {

  constructor(private db: AngularFireDatabase) { }

  private create() {
    const ref = this.db.list('/shopping-carts').push({
      itemsCount : {value : 0}
    });
    return ref;
  }

  public async getCart(): Promise<AngularFireObject<ShoppingCart>> {
    const cartId = await this.getOrCreateCartId();
    return this.db.object('/shopping-carts/' + cartId);
  }

  public async getItems(): Promise<AngularFireList<Item>> {
    const id = await this.getOrCreateCartId();
    return this.db.list('/shopping-carts/' + id + '/items/');
  }

  private getItem(cartId: string, productId: string): AngularFireObject<Item> {
    return this.db.object('/shopping-carts/' + cartId + '/items/' + productId);
  }

  private async getOrCreateCartId(): Promise<string> {
    const cartId = localStorage.getItem('cartId');
    if (cartId) { return cartId; }
    const result = await this.create();
    localStorage.setItem('cartId', result.key);
    return result.key;
  }

  async addToCart(product: Product) {
    const cartId = await this.getOrCreateCartId();
    this.updateCart(product, 1, cartId);
    this.updateCount(1, cartId);
  }

  async removeFromCart(product: Product) {
    const cartId = await this.getOrCreateCartId();
    this.updateCart(product, -1, cartId);
    this.updateCount(-1, cartId);
  }

  clearCart() {
    const cartId = localStorage.getItem('cartId');
    this.db.object('shopping-carts/' + cartId + '/items').remove();
    this.db.object('shopping-carts/' + cartId + '/itemsCount').update({value: 0});
  }

  private async updateCart(product, updater, cartId) {
    let quantity;
    const itemAFO: AngularFireObject<Item> = this.getItem(cartId, product.id);
    itemAFO.snapshotChanges().pipe(take(1)).subscribe(item => {
      if (item.payload.hasChild('/product')) {
        quantity = item.payload.val().quantity;
        if (quantity === 1 && updater === -1) {
          this.db.object('/shopping-carts/' + cartId + '/items/' + product.id).remove();
        } else {
        itemAFO.update({quantity: quantity + updater});
        }
      } else {
        itemAFO.set({product: product, quantity: 1});
      }
    });
  }

  private updateCount(ctr, cartId) {
    let count;
    const countAFO: AngularFireObject<Counter> = this.db.object('/shopping-carts/' + cartId + '/itemsCount/');
    countAFO.snapshotChanges().pipe(take(1)).subscribe(x => {
      count = x.payload.val().value;
      count = count + ctr;
      countAFO.update({value : count});
    });
  }

}

import { Injectable } from '@angular/core';
import { AngularFireDatabase } from 'angularfire2/database';
import { Product } from '../models/product';

@Injectable({
  providedIn: 'root'
})
export class ProductService {

  constructor(private db: AngularFireDatabase) {}

  create(product) {
    const recieptRef = this.db.list('/products').push(product);
    recieptRef.update({id: recieptRef.key});
  }

  getAll() {
    return this.db.list('/products');
  }

  get(prodId) {
    return this.db.object('/products/' + prodId);
  }

  update(prodId, product) {
    return this.db.object('/products/' + prodId).update(product);
  }

  delete(prodId) {
    return this.db.object('/products/' + prodId).remove();
  }

}

import { Order } from './../models/Order';
import { Observable } from 'rxjs';
import { DatabaseReference } from 'angularfire2/database/interfaces';
import { ShoppingCartService } from './shopping-cart.service';
import { AngularFireDatabase, AngularFireList } from 'angularfire2/database';
import { Injectable } from '@angular/core';
import { filter } from '../../../node_modules/rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class OrderService {

  constructor(private db: AngularFireDatabase, private cartService: ShoppingCartService) { }

  placeOrder(order) {
    const orderId = this.db.list('/orders').push(order);
    this.cartService.clearCart();
    orderId.update({ orderId : orderId.key});
    return orderId.key;
  }

  getAllOrders(): AngularFireList<Order> {
    return this.db.list('/orders');
  }
 /*  getOrderByUser(userId: string) {
    /* return this.db.list('/orders', ref => ref.child().orderByChild('userId').equalTo(userId)); */
    /* return this.db.list('/orders', (query: DatabaseReference) => {
      return query.orderByChild('userId').equalTo(userId);
    }); */
    /* return this.db.list('/orders', {
      query : {
        equalTo: 'userId'
      }
    });
    let allOrders$: Observable<Order[]>;
    allOrders$ = this.db.list('/orders').valueChanges();
    return allOrders$.pipe(filter(order => order === userId));

  } */
  getOrderedItems(orderId) {
    return this.db.list('/orders/' + orderId + '/items/');
  }
}

import { AppUser } from './../models/app-user';
import { UserService } from './user.service';
import { AuthService } from './auth.service';
import { Injectable } from '@angular/core';
import { CanActivate } from '../../../node_modules/@angular/router';
import { map, switchMap } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class AdminAuthGuardService implements CanActivate {

  constructor(private auth: AuthService, private userService: UserService) { }
  /* constructor(afDb: AngularFireDatabase) { afDb.list<T>('items').valueChanges().subscribe(console.log); } */

  canActivate() {

    this.auth.user$.subscribe(user => {console.log(user)});
    })
  );
  }
}

import { AppUser } from './../models/app-user';
import { UserService } from './user.service';
import { AuthService } from './auth.service';
import { Injectable } from '@angular/core';
import { CanActivate, Router } from '../../../node_modules/@angular/router';
import { map, switchMap } from 'rxjs/operators';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AdminAuthGuardService implements CanActivate {

  constructor(private auth: AuthService, private userService: UserService, private router: Router) { }

  canActivate() {
    let answer;
    /* this.auth.user$.pipe(map(user => {
      this.userService.get(user.uid).valueChanges().subscribe(profile => {
        if (profile.isAdmin) {
          console.log(true);
          answer = true;
        } else {
          answer = false;
        }
      });
    })
  ); */
  let userId: string;
  this.auth.user$.subscribe(profile => {
    userId = profile.uid;
    console.log(userId);
  });
  this.userService.get(userId).valueChanges().subscribe(user => {
    console.log(user);
  });
  if (answer) {
    return true;
  } else {
    this.router.navigate(['']);
    return false;
  }
  }
}

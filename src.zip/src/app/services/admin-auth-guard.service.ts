import { AppUser } from './../models/app-user';
import { UserService } from './user.service';
import { AuthService } from './auth.service';
import { Injectable } from '@angular/core';
import { CanActivate, Router } from '../../../node_modules/@angular/router';
import { switchMap, map } from 'rxjs/operators';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AdminAuthGuardService implements CanActivate {

  uid: string;
  answer: boolean;

  constructor(private auth: AuthService, private userService: UserService, private router: Router) { }

  canActivate() {
    this.auth.user$.subscribe(x => this.uid = x.uid);
    /* this.userService.get('/users' + this.uid + '/admin').valueChanges().subscribe(x => console.log(x)); */
    /* this.userService.get(this.uid).valueChanges().pipe(map(admin => {console.log(admin); this.answer = admin.isAdmin; })); */
    return true;
  }
}

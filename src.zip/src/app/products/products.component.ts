import { take } from 'rxjs/operators';
import { AngularFireDatabase } from 'angularfire2/database';
import { MainNavComponent } from './../main-nav/main-nav.component';
import { Subscription } from 'rxjs';
import { ShoppingCartService } from './../services/shopping-cart.service';
import { ActivatedRoute } from '@angular/router';
import { CategoryService } from './../services/category.service';
import { ProductService } from './../services/product.service';
import { Component, OnInit, OnDestroy } from '@angular/core';
import { Product } from '../models/product';

@Component({
  selector: 'app-products',
  templateUrl: './products.component.html',
  styleUrls: ['./products.component.css']
})
export class ProductsComponent implements OnInit {

  products: any[] = [];
  filteredProducts: any[] = [];
  categories$;
  category;
  subscription: Subscription;
  cartNAV: MainNavComponent;
  cart;

  constructor(route: ActivatedRoute,
    prodService: ProductService,
    categoryService: CategoryService,
    private navCart: MainNavComponent,
    private cartService: ShoppingCartService) {

    prodService.getAll().valueChanges().subscribe(products => {
      this.products = products;
      this.categories$ = categoryService.getCategories().valueChanges();
      route.queryParamMap.subscribe(param => {
      this.category = param.get('category');

      this.filteredProducts = (this.category) ?
        this.products.filter(p => p.category === this.category) :
        this.products;
    });
    });
  }
  async ngOnInit() {
    const cartIn = await this.cartService.getCart();
    this.subscription = cartIn.valueChanges().subscribe(cart => this.cart = cart);
  }
}

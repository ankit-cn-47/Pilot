import { Router } from '@angular/router';
import { ShoppingCart } from './../models/shopping-carts';
import { ShoppingCartService } from './../services/shopping-cart.service';
import { AuthService } from './../services/auth.service';
import { Component, OnInit, AfterContentInit } from '@angular/core';
import { Observable } from 'rxjs';
import { BreakpointObserver, Breakpoints, BreakpointState } from '@angular/cdk/layout';
import { map } from 'rxjs/operators';
import { AngularFireObject } from 'angularfire2/database';

@Component({
  selector: 'app-main-nav',
  templateUrl: './main-nav.component.html',
  styleUrls: ['./main-nav.component.css']
})
export class MainNavComponent implements OnInit {
  itemCount: number;
  cart$;
  cartAFO: AngularFireObject<ShoppingCart>;

  isHandset$: Observable<boolean> = this.breakpointObserver.observe(Breakpoints.Handset)
    .pipe(
      map(result => result.matches)
    );

  constructor(private breakpointObserver: BreakpointObserver,
    private auth: AuthService,
    private cartService: ShoppingCartService,
    private route: Router) { }

  async ngOnInit() {
    this.cartAFO = await this.cartService.getCart();
    this.cart$ = this.cartAFO.valueChanges();
    this.cart$.subscribe(cart => {
      this.itemCount = cart.itemsCount.value;
    });
  }
    /*     this.cartAFO = await this.cartService.getCart();
    this.cartAFO.valueChanges().subscribe(cart => {
      this.itemCount = 0;
      if (cart != null) {
        /* tslint:disable-next-line:forin
        for (const productId in cart.items) {
          this.itemCount += cart.items[productId].quantity;
        }
      }}
    ); */

  logout() {
    this.auth.logout();
    this.route.navigate(['/']);
  }

}

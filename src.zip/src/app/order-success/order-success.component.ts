import { Subscription } from 'rxjs';
import { ActivatedRoute } from '@angular/router';
import { Component, OnInit, OnDestroy } from '@angular/core';

@Component({
  selector: 'app-order-success',
  templateUrl: './order-success.component.html',
  styleUrls: ['./order-success.component.css']
})
export class OrderSuccessComponent implements OnInit, OnDestroy {
  orderId;
  deliveryDate;
  paramSubscription: Subscription;

  constructor(private route: ActivatedRoute) { }

  ngOnInit() {
    this.paramSubscription = this.route.params.subscribe(orderId => {
      this.orderId = orderId;
    });
    this.deliveryDate = Date.now() + 3;
  }

  ngOnDestroy() {
    this.paramSubscription.unsubscribe();
  }

}

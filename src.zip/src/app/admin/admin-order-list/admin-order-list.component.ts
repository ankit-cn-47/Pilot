import { Subscription } from 'rxjs';
import { OrderService } from './../../services/order.service';
import { ActivatedRoute } from '@angular/router';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-admin-order-list',
  templateUrl: './admin-order-list.component.html',
  styleUrls: ['./admin-order-list.component.css']
})
export class AdminOrderListComponent implements OnInit {

  orderId;
  items$;
  subscription: Subscription;

  constructor(private route: ActivatedRoute, private orderService: OrderService) { }

  async ngOnInit() {
    this.route.params.subscribe(orderId => this.orderId = orderId.id);
    const items = await this.orderService.getOrderedItems(this.orderId);
    this.items$ = items.valueChanges();
  }
}

import { Subscription } from 'rxjs';
import { OrderService } from './../../services/order.service';
import { Component, OnInit, OnDestroy } from '@angular/core';

@Component({
  selector: 'app-admin-orders',
  templateUrl: './admin-orders.component.html',
  styleUrls: ['./admin-orders.component.css']
})
export class AdminOrdersComponent implements OnInit, OnDestroy {
  orderList: any[];
  subscription: Subscription;
  filteredOrders: any[];
  constructor(private orderService: OrderService) {
    this.subscription = this.orderService.getAllOrders().valueChanges().subscribe(order => this.filteredOrders = this.orderList = order);
  }

  filter(query) {
    this.filteredOrders = (query) ?
    this.orderList.filter(o => o.orderId.toLowerCase().includes(query.toLowerCase())) :
    this.orderList;
  }

  ngOnDestroy() {
    this.subscription.unsubscribe();
  }
  ngOnInit() {
  }

}

import { Item } from './../models/item';
import { Observable, Subscription } from 'rxjs';
import { ShoppingCartService } from './../services/shopping-cart.service';
import { ShoppingCart } from './../models/shopping-carts';
import { Component, OnInit, Input, OnDestroy } from '@angular/core';

@Component({
  selector: 'app-cart-summary',
  templateUrl: './cart-summary.component.html',
  styleUrls: ['./cart-summary.component.css']
})
export class CartSummaryComponent implements OnInit, OnDestroy {
  total: number;
  cart$: Observable<ShoppingCart>;
  items$: Observable<Item[]>;
  cartSubscription: Subscription;
  itemSubscription: Subscription;
  itemsCount: number;

  constructor(private cartService: ShoppingCartService) { }

  async ngOnInit() {
    const cart = await this.cartService.getCart();
    this.cart$ = cart.valueChanges();
    this.cartSubscription = this.cart$.subscribe(cartIn => {
      this.itemsCount = cartIn.itemsCount.value;
    });

    const itemsAFL = await this.cartService.getItems();
    this.items$ = itemsAFL.valueChanges();
    this.itemSubscription = this.items$.subscribe(x => {
      this.total = 0;
      for (const i of x) {
        this.total = this.total + ((i.product.price) * (i.quantity));
      }
    });
  }
  ngOnDestroy() {
    this.itemSubscription.unsubscribe();
    this.cartSubscription.unsubscribe();
  }

}

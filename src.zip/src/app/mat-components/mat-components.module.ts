import { NgModule } from '@angular/core';
import {MatCheckboxModule} from '@angular/material/checkbox';

@NgModule({
  exports: [
    MatCheckboxModule
  ]
})
export class MatComponentsModule { }

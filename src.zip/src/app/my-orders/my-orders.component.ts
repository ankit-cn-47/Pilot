import { Order } from './../models/Order';
import { Observable } from 'rxjs';
import { OrderService } from './../services/order.service';
import { AuthService } from './../services/auth.service';
import { Component, Inject } from '@angular/core';
import { DOCUMENT } from '../../../node_modules/@angular/common';

@Component({
  selector: 'app-my-orders',
  templateUrl: './my-orders.component.html',
  styleUrls: ['./my-orders.component.css']
})
export class MyOrdersComponent {

  orders$: Observable<Order[]>;
  user;
  userName;
  oid;
 /*  orderIds: Array<string>;
  orderDate: Array<number>; */

  constructor(@Inject(DOCUMENT) document,
  private authService: AuthService,
  private orderService: OrderService) {
    authService.user$.subscribe(user => {
      this.user = user.uid;
      this.userName = user.displayName;
     });
    this.orders$ = orderService.getAllOrders().valueChanges();    
    /* this.orders$.subscribe(orders => {
      // tslint:disable-next-line:forin
      let ctr = 0;
      for (let i = 0; i < orders.length ; i++) {
          if (orders[i].userId === this.user) {
            this.orderIds[ctr] = orders[i].orderId;
            this.orderDate[ctr] = orders[i].datePlaced;
            ctr++;
          }
        }
    } ); */
  }
  updateOID(i) {
    this.oid = document.getElementById(i).innerHTML;
  }
}

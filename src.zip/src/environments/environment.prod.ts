export const environment = {
  production: true,
  firebase: {
    apiKey: 'AIzaSyBeAvKokZ49GWDZOtKJNCGt1zeTCJ1SrQ4',
    authDomain: 'oshop-946a1.firebaseapp.com',
    databaseURL: 'https://oshop-946a1.firebaseio.com',
    projectId: 'oshop-946a1',
    storageBucket: 'oshop-946a1.appspot.com',
    messagingSenderId: '1072311339348'
  }
};
